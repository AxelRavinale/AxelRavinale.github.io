from django.utils.translation import gettext_lazy as _

ROLES_TRIPULACION = [
    ('piloto', 'Piloto'),
    ('copiloto', 'Copiloto'),
    ('asistente', 'Asistente de vuelo'),
    ('jefe_cabina', 'Jefe de Cabina'),
    ('azafata', 'Azafata'),
    ('ingeniero', 'Ingeniero de Vuelo')
]
